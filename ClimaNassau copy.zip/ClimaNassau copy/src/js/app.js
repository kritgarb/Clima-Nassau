const apiKey = ''; // Sua chave da API

// Função assíncrona para buscar dados do clima com base na cidade fornecida
     // Mostra o carregador
     // Faz uma requisição para a API do OpenWeatherMap com a cidade e a chave da API
     // Converte a resposta da API de JSON para um objeto JavaScript
     // Esconde o carregador
     // Verifica se a resposta da API foi bem-sucedida (codigo 200)

// Adiciona um evento para executar a função quando o DOM estiver completamente carregado

